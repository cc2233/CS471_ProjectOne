
Fall 2015 CS 471 Professor Price

Project One

by Caroline Chey



This is a Priority Queue based program; dispatcher simulator.
There are three possible states for a process: Ready, Blocked, Running

A Priority Queue of Processes maintains all Ready Processes. 
A List is used to hold all Blocked Processes.
There cannot be more than one Process Running at a time.



Provided input data files: 
   processes_A.txt 
      and 
   processes.B.txt

Program will read in from input file to construct a Priority Queue.

three different levels of priority: 3 is highest and 1 is lowest.

